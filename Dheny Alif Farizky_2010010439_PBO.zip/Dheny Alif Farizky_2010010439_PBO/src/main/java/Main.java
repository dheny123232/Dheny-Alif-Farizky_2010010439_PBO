import frame.SepatuViewFrame;
import frame.JenisViewFrame;

public class Main {
    public static void main(String[] args) {
        //Koneksi.getConnection();
//        JenisViewFrame viewFrame = new JenisViewFrame();
//        viewFrame.setVisible(true);

        SepatuViewFrame viewFrame = new SepatuViewFrame();
        viewFrame.setVisible(true);

    }
}
